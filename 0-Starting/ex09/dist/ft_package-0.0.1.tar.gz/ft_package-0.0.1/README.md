# ft_package

`ft_package` is a test package that contains the function `count_in_list`.

## Crea la distribución del paquete usando setuptools:

python setup.py sdist bdist_wheel

This generate the necesary files in dist/:

### Install

At main directory, install the package localy:

```bash
pip install .