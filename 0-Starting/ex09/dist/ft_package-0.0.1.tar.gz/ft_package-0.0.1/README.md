# ft_package

`ft_package` is a test package that contains the function `count_in_list`.

### Install

At main directory, install the package localy:

```bash
pip install .